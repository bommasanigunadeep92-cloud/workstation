/**
 * Allocation Service
 * 
 * Implements Process Synchronization, Critical Section Protection,
 * Resource Allocation, and Direct Resource Handoff.
 */

const db = require('../config/db');
const { globalSemaphore } = require('../utils/semaphore');

let ioInstance = null;

function setSocketIO(io) {
  ioInstance = io;
}

function broadcastEvent(eventName, data) {
  if (ioInstance) {
    ioInstance.emit(eventName, data);
  }
}

/**
 * Initialize / synchronize semaphore with database on startup
 */
async function syncSystemState() {
  try {
    const workstations = await db.query('SELECT * FROM workstations');
    const available = workstations.filter(w => w.status === 'AVAILABLE').length;
    const waitingRows = await db.query('SELECT * FROM waiting_queue WHERE status = ?', ['WAITING']);
    
    // Sort waiting rows by position
    const sortedWaiters = waitingRows.sort((a, b) => a.position - b.position).map(w => ({
      studentId: w.student_id,
      position: w.position,
      queuedAt: w.request_time
    }));

    globalSemaphore.syncState(available, sortedWaiters);
    console.log(`[OS Semaphore] Synchronized. Total: ${workstations.length}, Available: ${available}, S = ${globalSemaphore.S}, Waiting: ${sortedWaiters.length}`);
  } catch (err) {
    console.warn('[OS Semaphore] Sync state warning:', err.message);
  }
}

/**
 * Student requests a workstation
 * Executes wait(S) within critical section
 */
async function requestWorkstation(studentId, studentName = null) {
  // If studentName not provided, fetch from students table
  if (!studentName) {
    const studentRows = await db.query('SELECT name FROM students WHERE student_id = ?', [studentId]);
    studentName = studentRows.length > 0 ? studentRows[0].name : studentId;
  }

  // 1. Validation: Prevent duplicate requests
  const activeAllocs = await db.query(
    'SELECT * FROM allocations WHERE student_id = ? AND status = ?',
    [studentId, 'ACTIVE']
  );
  if (activeAllocs.length > 0) {
    throw new Error('You already have an active workstation allocated (' + activeAllocs[0].workstation_id + ').');
  }

  const waitingEntry = await db.query(
    'SELECT * FROM waiting_queue WHERE student_id = ? AND status = ?',
    [studentId, 'WAITING']
  );
  if (waitingEntry.length > 0) {
    throw new Error(`You are already in the waiting queue at Position #${waitingEntry[0].position}.`);
  }

  // 2. Critical Section Entry (Atomic wait(S))
  const waitResult = await globalSemaphore.wait({
    studentId,
    studentName,
    timestamp: new Date()
  });

  if (waitResult.acquired) {
    // S was > 0. Workstation is successfully allocated.
    // Find first available workstation
    const availWorkstations = await db.query(
      'SELECT * FROM workstations WHERE status = ?',
      ['AVAILABLE']
    );

    if (availWorkstations.length === 0) {
      // Edge-case safeguard: sync semaphore and queue student
      console.error('[CRITICAL] Semaphore desync: S > 0 but no available workstation found!');
      globalSemaphore.S = 0;
      const qPos = 1;
      await db.query(
        'INSERT INTO waiting_queue (student_id, position, status, request_time) VALUES (?, ?, ?, NOW())',
        [studentId, qPos, 'WAITING']
      );
      return { success: true, allocated: false, queued: true, position: qPos, semaphore: 0 };
    }

    const assignedWs = availWorkstations[0];

    // Update workstation status
    await db.query(
      'UPDATE workstations SET status = ?, current_student_id = ? WHERE id = ?',
      ['OCCUPIED', studentId, assignedWs.id]
    );

    // Record allocation
    await db.query(
      'INSERT INTO allocations (student_id, workstation_id, status, allocated_at) VALUES (?, ?, ?, NOW())',
      [studentId, assignedWs.id, 'ACTIVE']
    );

    // Audit Log
    const semBefore = waitResult.semaphore + 1;
    const semAfter = waitResult.semaphore;
    await db.query(
      'INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after, workstation_id, student_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        'ALLOCATION',
        studentId,
        `Workstation ${assignedWs.id} allocated to ${studentName} (${studentId}). Semaphore wait(S) executed: S=${semBefore} -> S=${semAfter}`,
        semBefore,
        semAfter,
        assignedWs.id,
        studentId
      ]
    );

    // Broadcast real-time update
    const labState = await getLaboratoryState();
    broadcastEvent('STATE_UPDATED', labState);
    broadcastEvent('ACTIVITY_LOG', {
      action: 'ALLOCATION',
      message: `${studentName} allocated ${assignedWs.id}`,
      semaphore: semAfter,
      timestamp: new Date()
    });

    return {
      success: true,
      allocated: true,
      queued: false,
      workstationId: assignedWs.id,
      workstationName: assignedWs.name,
      allocatedAt: new Date(),
      semaphore: semAfter,
      message: `Workstation ${assignedWs.id} successfully allocated!`
    };
  } else {
    // S == 0. No free workstations. Student enters FIFO waiting queue.
    const position = waitResult.position;
    await db.query(
      'INSERT INTO waiting_queue (student_id, position, status, request_time) VALUES (?, ?, ?, NOW())',
      [studentId, position, 'WAITING']
    );

    await db.query(
      'INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after, student_id) VALUES (?, ?, ?, ?, ?, ?)',
      [
        'QUEUE_JOIN',
        studentId,
        `All workstations occupied (S=0). Student ${studentName} (${studentId}) added to FIFO waiting queue at position #${position}.`,
        0,
        0,
        studentId
      ]
    );

    const labState = await getLaboratoryState();
    broadcastEvent('STATE_UPDATED', labState);
    broadcastEvent('ACTIVITY_LOG', {
      action: 'QUEUE_JOIN',
      message: `${studentName} joined waiting queue at #${position}`,
      semaphore: 0,
      timestamp: new Date()
    });

    return {
      success: true,
      allocated: false,
      queued: true,
      position,
      semaphore: 0,
      message: `All workstations are occupied. You are at position #${position} in the waiting queue.`
    };
  }
}

/**
 * Release workstation / Student logout
 * Executes signal(S) or direct handoff to waiting process
 */
async function releaseWorkstation(studentId, workstationId = null) {
  let activeAlloc = null;

  if (studentId) {
    const rows = await db.query(
      'SELECT * FROM allocations WHERE student_id = ? AND status = ?',
      [studentId, 'ACTIVE']
    );
    if (rows.length > 0) activeAlloc = rows[0];
  } else if (workstationId) {
    const rows = await db.query(
      'SELECT * FROM allocations WHERE workstation_id = ? AND status = ?',
      [workstationId, 'ACTIVE']
    );
    if (rows.length > 0) activeAlloc = rows[0];
  }

  if (!activeAlloc) {
    // Check if the student is in the waiting queue and wants to cancel waiting
    if (studentId) {
      const waitRows = await db.query(
        'SELECT * FROM waiting_queue WHERE student_id = ? AND status = ?',
        [studentId, 'WAITING']
      );
      if (waitRows.length > 0) {
        await globalSemaphore.removeWaiter(studentId);
        await db.query(
          'UPDATE waiting_queue SET status = ? WHERE id = ?',
          ['CANCELLED', waitRows[0].id]
        );
        // Advance remaining waiters
        await db.query('UPDATE waiting_queue SET position = position - 1 WHERE status = ? AND position > ?', ['WAITING', waitRows[0].position]);

        const labState = await getLaboratoryState();
        broadcastEvent('STATE_UPDATED', labState);
        return { success: true, message: 'You have left the waiting queue.' };
      }
    }
    throw new Error('No active workstation allocation found to release.');
  }

  const targetWsId = activeAlloc.workstation_id;
  const releasedStudentId = activeAlloc.student_id;

  // Calculate session duration
  const startMs = new Date(activeAlloc.allocated_at).getTime();
  const endMs = Date.now();
  const durationSec = Math.max(1, Math.round((endMs - startMs) / 1000));

  // Mark current allocation as COMPLETED
  await db.query(
    'UPDATE allocations SET status = ?, released_at = NOW(), duration_seconds = ? WHERE id = ?',
    ['COMPLETED', durationSec, activeAlloc.id]
  );

  // Check FIFO Waiting Queue for waiting students
  const waitingRows = await db.query(
    'SELECT * FROM waiting_queue WHERE status = ? ORDER BY position ASC LIMIT 1',
    ['WAITING']
  );

  if (waitingRows.length > 0) {
    // DIRECT RESOURCE HANDOFF
    // The top waiting student gets the freed workstation immediately.
    // Crucial OS Principle: Semaphore count S does NOT increment!
    const nextWaiter = waitingRows[0];
    const signalResult = await globalSemaphore.signal(true);

    // Update queue record
    await db.query(
      'UPDATE waiting_queue SET status = ?, allocated_workstation_id = ?, resolved_time = NOW() WHERE id = ?',
      ['ALLOCATED', targetWsId, nextWaiter.id]
    );

    // Shift remaining queue positions forward
    await db.query(
      'UPDATE waiting_queue SET position = position - 1 WHERE status = ?',
      ['WAITING']
    );

    // Reassign workstation directly to top waiter
    await db.query(
      'UPDATE workstations SET status = ?, current_student_id = ? WHERE id = ?',
      ['OCCUPIED', nextWaiter.student_id, targetWsId]
    );

    // Create new allocation record for next waiter
    await db.query(
      'INSERT INTO allocations (student_id, workstation_id, status, allocated_at) VALUES (?, ?, ?, NOW())',
      [nextWaiter.student_id, targetWsId, 'ACTIVE']
    );

    // Audit log
    await db.query(
      'INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after, workstation_id, student_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        'DIRECT_HANDOFF',
        'KERNEL',
        `Workstation ${targetWsId} released by ${releasedStudentId} and directly handed off to waiting student ${nextWaiter.student_id}. Semaphore S remains 0.`,
        0,
        0,
        targetWsId,
        nextWaiter.student_id
      ]
    );

    const labState = await getLaboratoryState();
    broadcastEvent('STATE_UPDATED', labState);
    broadcastEvent('DIRECT_HANDOFF_EVENT', {
      workstationId: targetWsId,
      previousStudent: releasedStudentId,
      newStudent: nextWaiter.student_id,
      timestamp: new Date()
    });

    return {
      success: true,
      released: true,
      directHandoff: true,
      workstationId: targetWsId,
      nextStudentId: nextWaiter.student_id,
      semaphore: 0,
      message: `Workstation ${targetWsId} released and directly handed off to waiting student ${nextWaiter.student_id}.`
    };
  } else {
    // NO WAITERS: Normal release and signal(S)
    const semBefore = globalSemaphore.S;
    const signalResult = await globalSemaphore.signal(false);
    const semAfter = signalResult.semaphore;

    // Workstation becomes AVAILABLE
    await db.query(
      'UPDATE workstations SET status = ?, current_student_id = NULL WHERE id = ?',
      ['AVAILABLE', targetWsId]
    );

    // Audit log
    await db.query(
      'INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after, workstation_id, student_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        'RELEASE',
        releasedStudentId,
        `Workstation ${targetWsId} released by student ${releasedStudentId}. Semaphore signal(S) executed: S=${semBefore} -> S=${semAfter}.`,
        semBefore,
        semAfter,
        targetWsId,
        releasedStudentId
      ]
    );

    const labState = await getLaboratoryState();
    broadcastEvent('STATE_UPDATED', labState);
    broadcastEvent('ACTIVITY_LOG', {
      action: 'RELEASE',
      message: `Workstation ${targetWsId} released. S=${semAfter}`,
      semaphore: semAfter,
      timestamp: new Date()
    });

    return {
      success: true,
      released: true,
      directHandoff: false,
      workstationId: targetWsId,
      semaphore: semAfter,
      message: `Workstation ${targetWsId} released successfully. Available count increased.`
    };
  }
}

/**
 * Administrative safe reset of laboratory
 */
async function resetLaboratory() {
  await globalSemaphore.reset(parseInt(process.env.TOTAL_WORKSTATIONS, 10) || 10);

  // Revoke active allocations
  await db.query("UPDATE allocations SET status = 'REVOKED', released_at = NOW() WHERE status = 'ACTIVE'");

  // Clear waiting queue
  await db.query("UPDATE waiting_queue SET status = 'CANCELLED' WHERE status = 'WAITING'");

  // Reset all workstations to AVAILABLE
  await db.query("UPDATE workstations SET status = 'AVAILABLE', current_student_id = NULL");

  // Log reset
  await db.query(
    'INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after) VALUES (?, ?, ?, ?, ?)',
    ['ADMIN_RESET', 'ADMIN', 'Laboratory safe reset executed by Administrator. All workstations released. Semaphore S = 10.', 0, 10]
  );

  const labState = await getLaboratoryState();
  broadcastEvent('STATE_UPDATED', labState);
  broadcastEvent('ADMIN_RESET_EVENT', { timestamp: new Date() });

  return { success: true, message: 'Laboratory reset successfully. Semaphore S = 10.' };
}

/**
 * Fetch full real-time state of the laboratory
 */
async function getLaboratoryState() {
  const workstations = await db.query('SELECT * FROM workstations ORDER BY id ASC');
  const activeAllocs = await db.query(`
    SELECT a.*, s.name as student_name, s.email as student_email, s.department
    FROM allocations a
    JOIN students s ON a.student_id = s.student_id
    WHERE a.status = 'ACTIVE'
  `);

  const waitingQueue = await db.query(`
    SELECT q.*, s.name as student_name, s.email as student_email, s.department
    FROM waiting_queue q
    JOIN students s ON q.student_id = s.student_id
    WHERE q.status = 'WAITING'
    ORDER BY q.position ASC
  `);

  // Map active allocation details into workstations
  const wsMap = workstations.map(ws => {
    const alloc = activeAllocs.find(a => a.workstation_id === ws.id);
    return {
      ...ws,
      student_name: alloc ? alloc.student_name : null,
      student_department: alloc ? alloc.department : null,
      allocated_at: alloc ? alloc.allocated_at : null
    };
  });

  const total = workstations.length;
  const occupied = workstations.filter(w => w.status === 'OCCUPIED').length;
  const available = total - occupied;
  const waitingCount = waitingQueue.length;

  return {
    totalWorkstations: total,
    availableWorkstations: available,
    occupiedWorkstations: occupied,
    waitingStudents: waitingCount,
    semaphore: globalSemaphore.S,
    workstations: wsMap,
    waitingQueue,
    activeAllocations: activeAllocs
  };
}

module.exports = {
  setSocketIO,
  syncSystemState,
  requestWorkstation,
  releaseWorkstation,
  resetLaboratory,
  getLaboratoryState
};
