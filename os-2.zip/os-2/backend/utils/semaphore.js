/**
 * Operating Systems Core: Counting Semaphore & Mutual Exclusion Mutex
 * 
 * Based on Edsger Dijkstra's semaphore concept:
 * - S = counting integer representing available identical resources (Workstations)
 * - P(S) / wait(S): Decrement S if S > 0, otherwise block process in FIFO queue.
 * - V(S) / signal(S): Increment S if no process is waiting; if processes are waiting,
 *   unblock the first waiting process (FIFO) and transfer resource directly.
 */

class Mutex {
  constructor() {
    this._locked = false;
    this._waitingQueue = [];
  }

  /**
   * Acquire mutual exclusion lock (Critical Section Entry)
   */
  async acquire() {
    if (!this._locked) {
      this._locked = true;
      return () => this.release();
    }

    return new Promise((resolve) => {
      this._waitingQueue.push(resolve);
    }).then(() => () => this.release());
  }

  /**
   * Release mutual exclusion lock (Critical Section Exit)
   */
  release() {
    if (this._waitingQueue.length > 0) {
      const nextResolve = this._waitingQueue.shift();
      nextResolve();
    } else {
      this._locked = false;
    }
  }

  isLocked() {
    return this._locked;
  }
}

class CountingSemaphore {
  /**
   * @param {number} totalResources - Total number of available resources (e.g. 10 workstations)
   */
  constructor(totalResources = 10) {
    this.total = parseInt(totalResources, 10) || 10;
    this.S = this.total; // Initial semaphore value S = Total
    this.mutex = new Mutex(); // Protects atomic semaphore operations & critical section
    this.waitingQueue = []; // FIFO Queue of waiting student processes
    this.activeAllocations = new Map(); // studentId -> workstationId
  }

  /**
   * Synchronize in-memory semaphore state with database count
   * Ensures consistency upon system boot or reset
   */
  syncState(availableCount, queueItems = [], activeMap = new Map()) {
    this.S = Math.max(0, Math.min(this.total, availableCount));
    this.waitingQueue = [...queueItems];
    this.activeAllocations = new Map(activeMap);
  }

  /**
   * Atomic P(S) / wait(S) operation
   * @param {Object} processInfo - { studentId, studentName, timestamp }
   * @returns {Object} { success, acquired, queued, position, semaphore, workstationId }
   */
  async wait(processInfo) {
    const unlock = await this.mutex.acquire();
    try {
      // Rule 4: Prevent S from becoming negative
      if (this.S > 0) {
        // S > 0: Resource available
        this.S -= 1;
        return {
          acquired: true,
          queued: false,
          semaphore: this.S,
          position: null
        };
      } else {
        // S == 0: No resource available. Process blocks and enters FIFO waiting queue.
        const position = this.waitingQueue.length + 1;
        const queueEntry = {
          ...processInfo,
          position,
          queuedAt: new Date()
        };
        this.waitingQueue.push(queueEntry);
        return {
          acquired: false,
          queued: true,
          semaphore: this.S, // S stays 0
          position
        };
      }
    } finally {
      unlock();
    }
  }

  /**
   * Atomic V(S) / signal(S) operation
   * @param {boolean} hasWaiterDirectHandoff - If true, released workstation is passed to waiter
   * @returns {Object} { semaphore, handedOffTo, remainingQueue }
   */
  async signal(hasWaiterDirectHandoff = false) {
    const unlock = await this.mutex.acquire();
    try {
      if (hasWaiterDirectHandoff && this.waitingQueue.length > 0) {
        // Direct handoff: The next waiting process gets the workstation immediately.
        // Crucial OS rule: S does NOT increment because all resources remain allocated!
        const nextProcess = this.waitingQueue.shift();
        
        // Re-calculate positions in FIFO queue
        this.waitingQueue.forEach((item, index) => {
          item.position = index + 1;
        });

        return {
          handedOffTo: nextProcess,
          semaphore: this.S, // Remains 0
          remainingWaiters: this.waitingQueue.length
        };
      } else {
        // No waiters exist: Workstation is marked available and S increments
        if (this.S < this.total) {
          this.S += 1;
        }
        return {
          handedOffTo: null,
          semaphore: this.S,
          remainingWaiters: 0
        };
      }
    } finally {
      unlock();
    }
  }

  /**
   * Remove a student from waiting queue (e.g. cancellation)
   */
  async removeWaiter(studentId) {
    const unlock = await this.mutex.acquire();
    try {
      const idx = this.waitingQueue.findIndex(w => w.studentId === studentId);
      if (idx !== -1) {
        this.waitingQueue.splice(idx, 1);
        this.waitingQueue.forEach((item, i) => {
          item.position = i + 1;
        });
        return true;
      }
      return false;
    } finally {
      unlock();
    }
  }

  /**
   * Reset the semaphore to default clean state
   */
  async reset(total = this.total) {
    const unlock = await this.mutex.acquire();
    try {
      this.total = total;
      this.S = total;
      this.waitingQueue = [];
      this.activeAllocations.clear();
      return this.getState();
    } finally {
      unlock();
    }
  }

  /**
   * Inspect current semaphore metrics
   */
  getState() {
    return {
      total: this.total,
      available: this.S,
      occupied: this.total - this.S,
      semaphore: this.S,
      queueLength: this.waitingQueue.length,
      waitingQueue: [...this.waitingQueue]
    };
  }
}

// Export singleton instance and classes
const globalSemaphore = new CountingSemaphore(parseInt(process.env.TOTAL_WORKSTATIONS, 10) || 10);

module.exports = {
  Mutex,
  CountingSemaphore,
  globalSemaphore
};
