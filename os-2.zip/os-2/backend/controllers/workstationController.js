const db = require('../config/db');
const allocationService = require('../services/allocationService');
const { globalSemaphore } = require('../utils/semaphore');

/**
 * Get all workstations with active allocation details
 */
async function getWorkstations(req, res) {
  try {
    const state = await allocationService.getLaboratoryState();
    return res.json({
      success: true,
      workstations: state.workstations,
      metrics: {
        total: state.totalWorkstations,
        available: state.availableWorkstations,
        occupied: state.occupiedWorkstations,
        waiting: state.waitingStudents,
        semaphore: state.semaphore
      }
    });
  } catch (err) {
    console.error('[Workstation error]:', err);
    return res.status(500).json({ success: false, message: 'Failed to fetch workstations: ' + err.message });
  }
}

/**
 * Get laboratory real-time overview metrics
 */
async function getLabMetrics(req, res) {
  try {
    const state = await allocationService.getLaboratoryState();
    return res.json({
      success: true,
      data: {
        totalWorkstations: state.totalWorkstations,
        availableWorkstations: state.availableWorkstations,
        occupiedWorkstations: state.occupiedWorkstations,
        waitingStudents: state.waitingStudents,
        semaphore: state.semaphore
      }
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

module.exports = {
  getWorkstations,
  getLabMetrics
};
