const allocationService = require('../services/allocationService');
const db = require('../config/db');

/**
 * Student requests a workstation
 */
async function requestAllocation(req, res) {
  try {
    let studentId = req.session?.student?.studentId || req.body.studentId;
    let studentName = req.session?.student?.name || req.body.studentName;

    if (!studentId) {
      return res.status(400).json({ success: false, message: 'Student ID is required.' });
    }

    const result = await allocationService.requestWorkstation(studentId, studentName);
    return res.json(result);
  } catch (err) {
    console.error('[Allocation Request error]:', err.message);
    return res.status(400).json({ success: false, message: err.message });
  }
}

/**
 * Release workstation
 */
async function releaseAllocation(req, res) {
  try {
    const studentId = req.session?.student?.studentId || req.body.studentId;
    const workstationId = req.body.workstationId; // Used by Admin force-release

    if (!studentId && !workstationId) {
      return res.status(400).json({ success: false, message: 'Student ID or Workstation ID is required.' });
    }

    const result = await allocationService.releaseWorkstation(studentId, workstationId);
    return res.json(result);
  } catch (err) {
    console.error('[Allocation Release error]:', err.message);
    return res.status(400).json({ success: false, message: err.message });
  }
}

/**
 * Get current student's active status (allocated workstation or queue position)
 */
async function getMyStatus(req, res) {
  try {
    const studentId = req.session?.student?.studentId || req.query.studentId;
    if (!studentId) {
      return res.status(400).json({ success: false, message: 'Student ID is required.' });
    }

    // Check active allocation
    const allocRows = await db.query(
      'SELECT a.*, w.name as workstation_name FROM allocations a JOIN workstations w ON a.workstation_id = w.id WHERE a.student_id = ? AND a.status = ?',
      [studentId, 'ACTIVE']
    );

    if (allocRows.length > 0) {
      return res.json({
        success: true,
        status: 'ALLOCATED',
        allocation: allocRows[0],
        workstation: {
          id: allocRows[0].workstation_id,
          name: allocRows[0].workstation_name,
          allocatedAt: allocRows[0].allocated_at
        }
      });
    }

    // Check waiting queue
    const queueRows = await db.query(
      'SELECT * FROM waiting_queue WHERE student_id = ? AND status = ?',
      [studentId, 'WAITING']
    );

    if (queueRows.length > 0) {
      return res.json({
        success: true,
        status: 'WAITING',
        queue: queueRows[0],
        position: queueRows[0].position
      });
    }

    return res.json({
      success: true,
      status: 'IDLE',
      message: 'No active workstation or queue position.'
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

/**
 * Get current FIFO waiting queue
 */
async function getWaitingQueue(req, res) {
  try {
    const state = await allocationService.getLaboratoryState();
    return res.json({
      success: true,
      waitingQueue: state.waitingQueue,
      totalWaiting: state.waitingStudents
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

/**
 * Safe Administrative Reset
 */
async function resetLab(req, res) {
  try {
    const result = await allocationService.resetLaboratory();
    return res.json(result);
  } catch (err) {
    console.error('[Admin Reset error]:', err.message);
    return res.status(500).json({ success: false, message: err.message });
  }
}

module.exports = {
  requestAllocation,
  releaseAllocation,
  getMyStatus,
  getWaitingQueue,
  resetLab
};
