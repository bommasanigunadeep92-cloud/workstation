const db = require('../config/db');

/**
 * Get Laboratory Analytics & Charts Data
 */
async function getAnalytics(req, res) {
  try {
    const allocations = await db.query('SELECT * FROM allocations');
    const totalAllocations = allocations.length;

    // Completed allocations with duration
    const completed = allocations.filter(a => a.status === 'COMPLETED' && a.duration_seconds > 0);
    const avgDurationSec = completed.length > 0
      ? Math.round(completed.reduce((acc, curr) => acc + curr.duration_seconds, 0) / completed.length)
      : 0;

    // Workstation utilization frequency
    const wsUsageMap = {};
    for (let i = 1; i <= 10; i++) {
      wsUsageMap[`PC-${String(i).padStart(2, '0')}`] = 0;
    }
    allocations.forEach(a => {
      if (wsUsageMap[a.workstation_id] !== undefined) {
        wsUsageMap[a.workstation_id] += 1;
      } else {
        wsUsageMap[a.workstation_id] = 1;
      }
    });

    const workstationChart = {
      labels: Object.keys(wsUsageMap),
      data: Object.values(wsUsageMap)
    };

    // Hourly usage breakdown (00 to 23 hours)
    const hourlyCounts = new Array(24).fill(0);
    allocations.forEach(a => {
      const hour = new Date(a.allocated_at).getHours();
      if (!isNaN(hour)) {
        hourlyCounts[hour] += 1;
      }
    });

    // Current occupancy
    const workstations = await db.query('SELECT * FROM workstations');
    const occupiedCount = workstations.filter(w => w.status === 'OCCUPIED').length;
    const availableCount = workstations.filter(w => w.status === 'AVAILABLE').length;

    return res.json({
      success: true,
      stats: {
        totalAllocations,
        avgDurationMinutes: Math.round(avgDurationSec / 60),
        avgDurationSeconds: avgDurationSec,
        currentOccupancyRate: Math.round((occupiedCount / (workstations.length || 10)) * 100)
      },
      workstationUsage: workstationChart,
      hourlyDistribution: {
        labels: Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`),
        data: hourlyCounts
      },
      occupancyChart: {
        labels: ['Occupied', 'Available'],
        data: [occupiedCount, availableCount]
      }
    });
  } catch (err) {
    console.error('[Analytics error]:', err);
    return res.status(500).json({ success: false, message: 'Analytics failed: ' + err.message });
  }
}

/**
 * Get Allocation History Table
 */
async function getAllocationHistory(req, res) {
  try {
    const rows = await db.query(`
      SELECT a.*, s.name as student_name, s.department
      FROM allocations a
      JOIN students s ON a.student_id = s.student_id
      ORDER BY a.allocated_at DESC
      LIMIT 100
    `);

    return res.json({
      success: true,
      history: rows
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

/**
 * Get System Activity & Semaphore Audit Logs
 */
async function getActivityLogs(req, res) {
  try {
    const logs = await db.query('SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 50');
    return res.json({
      success: true,
      logs
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

module.exports = {
  getAnalytics,
  getAllocationHistory,
  getActivityLogs
};
