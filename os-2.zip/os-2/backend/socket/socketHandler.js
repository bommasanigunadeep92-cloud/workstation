const allocationService = require('../services/allocationService');

function initSocketIO(io) {
  allocationService.setSocketIO(io);

  io.on('connection', async (socket) => {
    // console.log(`[Socket.IO] Client connected: ${socket.id}`);

    // Immediately push current laboratory state to the newly connected client
    try {
      const state = await allocationService.getLaboratoryState();
      socket.emit('STATE_UPDATED', state);
    } catch (err) {
      console.warn('[Socket.IO] Failed to send initial state:', err.message);
    }

    // Client requests manual refresh via socket
    socket.on('REQUEST_STATE', async () => {
      try {
        const state = await allocationService.getLaboratoryState();
        socket.emit('STATE_UPDATED', state);
      } catch (err) {
        console.warn('[Socket.IO] Refresh state failed:', err.message);
      }
    });

    socket.on('disconnect', () => {
      // console.log(`[Socket.IO] Client disconnected: ${socket.id}`);
    });
  });
}

module.exports = {
  initSocketIO
};
