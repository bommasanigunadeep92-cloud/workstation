const express = require('express');
const router = express.Router();
const allocationController = require('../controllers/allocationController');

router.post('/request', allocationController.requestAllocation);
router.post('/release', allocationController.releaseAllocation);
router.get('/my-status', allocationController.getMyStatus);
router.get('/queue', allocationController.getWaitingQueue);
router.post('/reset', allocationController.resetLab);

module.exports = router;
