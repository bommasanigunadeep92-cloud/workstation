const express = require('express');
const router = express.Router();
const analyticsController = require('../controllers/analyticsController');

router.get('/stats', analyticsController.getAnalytics);
router.get('/history', analyticsController.getAllocationHistory);
router.get('/logs', analyticsController.getActivityLogs);

module.exports = router;
