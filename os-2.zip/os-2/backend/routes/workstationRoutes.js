const express = require('express');
const router = express.Router();
const workstationController = require('../controllers/workstationController');

router.get('/', workstationController.getWorkstations);
router.get('/metrics', workstationController.getLabMetrics);

module.exports = router;
