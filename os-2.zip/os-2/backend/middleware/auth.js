/**
 * Authentication Middleware
 */

function requireStudent(req, res, next) {
  if (req.session && req.session.student) {
    return next();
  }
  return res.status(401).json({ success: false, message: 'Authentication required. Please log in as a student.' });
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.admin) {
    return next();
  }
  return res.status(403).json({ success: false, message: 'Access denied. Administrator privileges required.' });
}

module.exports = {
  requireStudent,
  requireAdmin
};
