/**
 * Automated Concurrency Test: Race Condition Prevention & Critical Section Mutex
 * Tests simultaneous concurrent requests to verify thread safety and mutual exclusion.
 */

const assert = require('assert');
const { Mutex, CountingSemaphore } = require('../utils/semaphore');

async function runConcurrencyTests() {
  console.log('\n--- STARTING CONCURRENCY & RACE CONDITION TEST SUITE ---');

  // TEST 7 & 8: Simultaneous Requests
  console.log('TEST 7 & 8: Launching 20 simultaneous concurrent workstation requests on 5 workstations...');
  const TOTAL_RESOURCES = 5;
  const sem = new CountingSemaphore(TOTAL_RESOURCES);

  // We simulate 20 async requests initiated concurrently via Promise.all
  const promises = [];
  for (let i = 1; i <= 20; i++) {
    const studentId = `CONCUR_STU_${String(i).padStart(2, '0')}`;
    promises.push(
      sem.wait({
        studentId,
        studentName: `Concurrent Student ${i}`
      })
    );
  }

  const results = await Promise.all(promises);

  const acquired = results.filter(r => r.acquired === true);
  const queued = results.filter(r => r.queued === true);

  console.log(`Results: ${acquired.length} acquired, ${queued.length} queued.`);

  // Assertions
  assert.strictEqual(acquired.length, 5, 'Exactly 5 students must acquire workstations');
  assert.strictEqual(queued.length, 15, 'Exactly 15 students must be placed in FIFO queue');
  assert.strictEqual(sem.S, 0, 'Semaphore S must be 0 after all 5 resources are acquired');
  assert.strictEqual(sem.waitingQueue.length, 15, 'Queue length must be 15');

  // Verify FIFO positions are distinct 1 to 15 without duplicates
  const positions = queued.map(q => q.position).sort((a, b) => a - b);
  for (let i = 1; i <= 15; i++) {
    assert.strictEqual(positions[i - 1], i, `Queue position ${i} must exist and be unique`);
  }
  console.log('✓ TEST 7 & 8 PASSED: Mutual exclusion preserved. No race conditions occurred.');

  // TEST 9: Invariant Consistency Check
  console.log('TEST 9: Checking Semaphore consistency invariant (S >= 0 and Total = Occupied + S)...');
  assert(sem.S >= 0, 'Semaphore S must never be negative');
  const occupiedCount = TOTAL_RESOURCES - sem.S;
  assert.strictEqual(TOTAL_RESOURCES, occupiedCount + sem.S, 'Total must equal Occupied + S');
  console.log('✓ TEST 9 PASSED: Invariant S >= 0 holds.');

  // Mutex test
  console.log('Testing Mutex critical section mutual exclusion lock...');
  const mutex = new Mutex();
  let counter = 0;
  const incPromises = [];
  for (let i = 0; i < 50; i++) {
    incPromises.push((async () => {
      const unlock = await mutex.acquire();
      const temp = counter;
      await new Promise(r => setTimeout(r, 2)); // simulate async I/O in critical section
      counter = temp + 1;
      unlock();
    })());
  }
  await Promise.all(incPromises);
  assert.strictEqual(counter, 50, 'Counter must be exactly 50 after 50 concurrent locked increments');
  console.log('✓ Mutex critical section locked increments test passed.');

  console.log('\n=========================================');
  console.log('🎉 ALL CONCURRENCY TESTS PASSED!');
  console.log('=========================================\n');
}

runConcurrencyTests().catch(err => {
  console.error('Concurrency test failed:', err);
  process.exit(1);
});
