/**
 * Automated Test Suite: OS Counting Semaphore & FIFO Queue Logic
 * Tests core Semaphore operations: wait(S), signal(S), Direct Handoff, Queue ordering
 */

const assert = require('assert');
const { CountingSemaphore } = require('../utils/semaphore');

async function runSemaphoreTests() {
  console.log('\n--- STARTING OPERATING SYSTEMS SEMAPHORE TEST SUITE ---');

  // TEST 1: All workstations available (Initialization)
  console.log('TEST 1: Initializing Semaphore S with total workstations (10)...');
  const sem = new CountingSemaphore(10);
  assert.strictEqual(sem.S, 10, 'Semaphore S must be 10 initially');
  assert.strictEqual(sem.waitingQueue.length, 0, 'Waiting queue must be empty');
  console.log('✓ TEST 1 PASSED: Semaphore S = 10, Queue empty.');

  // TEST 2: One student requests a workstation
  console.log('TEST 2: One student requests a workstation (wait(S))...');
  const r1 = await sem.wait({ studentId: 'STU01', studentName: 'Alice' });
  assert.strictEqual(r1.acquired, true, 'Resource should be acquired');
  assert.strictEqual(sem.S, 9, 'Semaphore S must decrease from 10 to 9');
  console.log('✓ TEST 2 PASSED: wait(S) decremented S to 9.');

  // TEST 3: All workstations become occupied (Remaining 9 students request)
  console.log('TEST 3: Allocating remaining 9 workstations...');
  for (let i = 2; i <= 10; i++) {
    const res = await sem.wait({ studentId: `STU${String(i).padStart(2, '0')}`, studentName: `Student ${i}` });
    assert.strictEqual(res.acquired, true);
  }
  assert.strictEqual(sem.S, 0, 'Semaphore S must reach exactly 0');
  assert.strictEqual(sem.waitingQueue.length, 0, 'Queue should still be 0 as exactly 10 allocated');
  console.log('✓ TEST 3 PASSED: All 10 workstations occupied, Semaphore S = 0.');

  // TEST 4: Another student requests when S = 0 (Enters FIFO Queue)
  console.log('TEST 4: Student 11 & Student 12 request when S = 0...');
  const r11 = await sem.wait({ studentId: 'STU11', studentName: 'Student 11' });
  assert.strictEqual(r11.acquired, false, 'Resource must not be acquired');
  assert.strictEqual(r11.queued, true, 'Student must be queued');
  assert.strictEqual(r11.position, 1, 'Position must be 1');
  assert.strictEqual(sem.S, 0, 'Semaphore must never become negative');

  const r12 = await sem.wait({ studentId: 'STU12', studentName: 'Student 12' });
  assert.strictEqual(r12.queued, true);
  assert.strictEqual(r12.position, 2, 'Position must be 2');
  assert.strictEqual(sem.waitingQueue.length, 2);
  console.log('✓ TEST 4 PASSED: Student 11 & 12 placed in FIFO queue, S prevented from becoming negative.');

  // TEST 5 & 6: Student releases workstation with waiters -> DIRECT HANDOFF
  console.log('TEST 5 & 6: Student releases workstation with students waiting in queue...');
  const sigResult = await sem.signal(true); // Direct handoff
  assert.strictEqual(sigResult.handedOffTo.studentId, 'STU11', 'Student 11 must receive workstation (FIFO)');
  assert.strictEqual(sem.S, 0, 'Crucial OS Rule: S must remain 0 because workstation was handed off directly!');
  assert.strictEqual(sem.waitingQueue.length, 1, 'Waiting queue must now have 1 student');
  assert.strictEqual(sem.waitingQueue[0].studentId, 'STU12', 'STU12 must be top waiter');
  assert.strictEqual(sem.waitingQueue[0].position, 1, 'STU12 position must advance to 1');
  console.log('✓ TEST 5 & 6 PASSED: Direct handoff executed; STU11 received resource; STU12 advanced to #1; S remained 0.');

  // Release second workstation -> STU12 gets it
  const sigResult2 = await sem.signal(true);
  assert.strictEqual(sigResult2.handedOffTo.studentId, 'STU12');
  assert.strictEqual(sem.waitingQueue.length, 0, 'Queue is now empty');
  assert.strictEqual(sem.S, 0, 'S still 0 because all 10 workstations are occupied');
  console.log('✓ Direct handoff to STU12 passed.');

  // Release third workstation when queue is empty -> S increments
  console.log('Testing signal(S) when queue is empty (no direct handoff)...');
  const sigResult3 = await sem.signal(false);
  assert.strictEqual(sigResult3.handedOffTo, null);
  assert.strictEqual(sem.S, 1, 'Semaphore S must increment to 1');
  console.log('✓ signal(S) without waiters incremented S to 1.');

  console.log('\n=========================================');
  console.log('🎉 ALL OPERATING SYSTEMS TESTS PASSED!');
  console.log('=========================================\n');
}

runSemaphoreTests().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
