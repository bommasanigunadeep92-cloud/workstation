const http = require('http');
const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const { Server } = require('socket.io');
const dotenv = require('dotenv');

dotenv.config();

const { initDatabase } = require('./config/db');
const allocationService = require('./services/allocationService');
const { initSocketIO } = require('./socket/socketHandler');

// Route imports
const authRoutes = require('./routes/authRoutes');
const workstationRoutes = require('./routes/workstationRoutes');
const allocationRoutes = require('./routes/allocationRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');

const app = express();
const server = http.createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});
initSocketIO(io);

// Middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'os_workstation_allocation_semaphore_2026',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // set to true only if https
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  })
);

// Serve Frontend Static Files
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/workstations', workstationRoutes);
app.use('/api/allocations', allocationRoutes);
app.use('/api/analytics', analyticsRoutes);

// Fallback HTML Routes for clean browser navigation
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../frontend/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../frontend/register.html')));
app.get('/student-dashboard', (req, res) => res.sendFile(path.join(__dirname, '../frontend/student-dashboard.html')));
app.get('/admin-dashboard', (req, res) => res.sendFile(path.join(__dirname, '../frontend/admin-dashboard.html')));
app.get('/simulation', (req, res) => res.sendFile(path.join(__dirname, '../frontend/simulation.html')));
app.get('/analytics', (req, res) => res.sendFile(path.join(__dirname, '../frontend/analytics.html')));

// Root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('[Server Error]:', err.stack);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

let currentPort = parseInt(process.env.PORT, 10) || 5000;

function listenOnPort(port) {
  server.listen(port, () => {
    console.log('\n=============================================================');
    console.log('   COMPUTER LABORATORY WORKSTATION ALLOCATION SYSTEM');
    console.log('   Operating Systems Counting Semaphore Implementation');
    console.log('=============================================================');
    console.log(`🚀 Server running on: http://localhost:${port}`);
    console.log(`📊 Landing Page:      http://localhost:${port}/index.html`);
    console.log(`👨‍💻 Student Dashboard: http://localhost:${port}/student-dashboard.html`);
    console.log(`🛡️  Admin Dashboard:   http://localhost:${port}/admin-dashboard.html`);
    console.log(`⚙️  OS Simulation:     http://localhost:${port}/simulation.html`);
    console.log(`📈 Lab Analytics:     http://localhost:${port}/analytics.html`);
    console.log('=============================================================\n');
  });
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.warn(`\n[PORT NOTICE] Port ${currentPort} is already in use by another instance.`);
    currentPort += 1;
    console.log(`[PORT AUTO-RESOLVE] Automatically switching to port ${currentPort}...\n`);
    setTimeout(() => {
      listenOnPort(currentPort);
    }, 500);
  } else {
    console.error('Server listen error:', err);
    process.exit(1);
  }
});

async function startServer() {
  try {
    // 1. Initialize DB connection
    await initDatabase();

    // 2. Synchronize Semaphore state with database
    await allocationService.syncSystemState();

    // 3. Start HTTP + Socket.IO server
    listenOnPort(currentPort);
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();

module.exports = { app, server };
