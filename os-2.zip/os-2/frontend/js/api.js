/**
 * API Service Wrapper for Laboratory Workstation Allocation System
 */

const API = {
  // Authentication
  async register(data) {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  async loginStudent(studentId, password) {
    const res = await fetch('/api/auth/login/student', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId, password })
    });
    return res.json();
  },

  async loginAdmin(username, password) {
    const res = await fetch('/api/auth/login/admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    return res.json();
  },

  async getMe() {
    const res = await fetch('/api/auth/me');
    return res.json();
  },

  async logout() {
    const res = await fetch('/api/auth/logout', { method: 'POST' });
    return res.json();
  },

  // Workstations
  async getWorkstations() {
    const res = await fetch('/api/workstations');
    return res.json();
  },

  async getMetrics() {
    const res = await fetch('/api/workstations/metrics');
    return res.json();
  },

  // Allocations & Semaphore
  async requestWorkstation(studentId, studentName) {
    const res = await fetch('/api/allocations/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId, studentName })
    });
    return res.json();
  },

  async releaseWorkstation(studentId, workstationId) {
    const res = await fetch('/api/allocations/release', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId, workstationId })
    });
    return res.json();
  },

  async getMyStatus(studentId) {
    const url = studentId ? `/api/allocations/my-status?studentId=${encodeURIComponent(studentId)}` : '/api/allocations/my-status';
    const res = await fetch(url);
    return res.json();
  },

  async getWaitingQueue() {
    const res = await fetch('/api/allocations/queue');
    return res.json();
  },

  async resetLaboratory() {
    const res = await fetch('/api/allocations/reset', { method: 'POST' });
    return res.json();
  },

  // Analytics & Logs
  async getAnalytics() {
    const res = await fetch('/api/analytics/stats');
    return res.json();
  },

  async getHistory() {
    const res = await fetch('/api/analytics/history');
    return res.json();
  },

  async getActivityLogs() {
    const res = await fetch('/api/analytics/logs');
    return res.json();
  }
};

/**
 * Toast Notification Helper
 */
function showToast(message, type = 'info', title = 'Lab Notification') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container-custom';
    document.body.appendChild(container);
  }

  const bgColors = {
    success: 'border-success bg-dark text-success',
    danger: 'border-danger bg-dark text-danger',
    warning: 'border-warning bg-dark text-warning',
    info: 'border-primary bg-dark text-primary'
  };

  const toastId = 'toast_' + Date.now();
  const html = `
    <div id="${toastId}" class="toast align-items-center text-white bg-dark border ${bgColors[type] || 'border-secondary'} shadow-lg mb-2" role="alert" aria-live="assertive" aria-atomic="true" style="min-width: 280px;">
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center gap-2">
          <i class="bi ${type === 'success' ? 'bi-check-circle-fill text-success' : type === 'danger' ? 'bi-x-circle-fill text-danger' : type === 'warning' ? 'bi-exclamation-triangle-fill text-warning' : 'bi-info-circle-fill text-primary'} fs-5"></i>
          <div>
            <div class="fw-bold small text-white">${title}</div>
            <div class="small text-light opacity-75">${message}</div>
          </div>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  `;

  container.insertAdjacentHTML('beforeend', html);
  const elem = document.getElementById(toastId);
  const bsToast = new bootstrap.Toast(elem, { delay: 4000 });
  bsToast.show();
  elem.addEventListener('hidden.bs.toast', () => elem.remove());
}

window.API = API;
window.showToast = showToast;
