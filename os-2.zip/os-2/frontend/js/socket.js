/**
 * Client-Side Socket.IO Real-Time Synchronization
 */

let socket = null;
const stateListeners = [];
const activityListeners = [];

function initRealtimeUpdates() {
  if (typeof io === 'undefined') {
    console.warn('[Socket.IO] io library not loaded. Realtime updates fallback to polling.');
    return;
  }

  socket = io();

  socket.on('connect', () => {
    // console.log('[Socket.IO] Connected to laboratory server with ID:', socket.id);
  });

  socket.on('STATE_UPDATED', (state) => {
    stateListeners.forEach(fn => {
      try { fn(state); } catch (e) { console.error('Error in state listener:', e); }
    });
  });

  socket.on('ACTIVITY_LOG', (log) => {
    activityListeners.forEach(fn => {
      try { fn(log); } catch (e) { console.error('Error in activity listener:', e); }
    });
  });

  socket.on('DIRECT_HANDOFF_EVENT', (data) => {
    if (window.showToast) {
      window.showToast(
        `Workstation ${data.workstationId} released and directly handed off to waiting student ${data.newStudent}!`,
        'warning',
        'Direct Handoff'
      );
    }
  });

  socket.on('ADMIN_RESET_EVENT', () => {
    if (window.showToast) {
      window.showToast('Laboratory was reset by the administrator.', 'info', 'System Reset');
    }
    // Refresh page or state
    if (typeof loadDashboardData === 'function') {
      loadDashboardData();
    }
  });
}

function onLaboratoryStateUpdate(fn) {
  stateListeners.push(fn);
}

function onActivityLog(fn) {
  activityListeners.push(fn);
}

window.initRealtimeUpdates = initRealtimeUpdates;
window.onLaboratoryStateUpdate = onLaboratoryStateUpdate;
window.onActivityLog = onActivityLog;
