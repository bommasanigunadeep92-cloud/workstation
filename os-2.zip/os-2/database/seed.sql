-- Initial Seed Data for Computer Laboratory Workstation Allocation System
USE workstation_allocation_db;

-- Clear previous seed data for fresh start (order matters due to foreign keys)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE activity_logs;
TRUNCATE TABLE waiting_queue;
TRUNCATE TABLE allocations;
TRUNCATE TABLE workstations;
TRUNCATE TABLE students;
TRUNCATE TABLE admins;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Insert 10 Workstations (PC-01 to PC-10)
INSERT INTO workstations (id, name, status, ip_address, specs) VALUES
('PC-01', 'Workstation 01', 'AVAILABLE', '192.168.1.101', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-02', 'Workstation 02', 'AVAILABLE', '192.168.1.102', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-03', 'Workstation 03', 'AVAILABLE', '192.168.1.103', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-04', 'Workstation 04', 'AVAILABLE', '192.168.1.104', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-05', 'Workstation 05', 'AVAILABLE', '192.168.1.105', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-06', 'Workstation 06', 'AVAILABLE', '192.168.1.106', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-07', 'Workstation 07', 'AVAILABLE', '192.168.1.107', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-08', 'Workstation 08', 'AVAILABLE', '192.168.1.108', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-09', 'Workstation 09', 'AVAILABLE', '192.168.1.109', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS'),
('PC-10', 'Workstation 10', 'AVAILABLE', '192.168.1.110', 'Intel Core i7-12700, 16GB RAM, 512GB NVMe, Ubuntu 22.04 LTS');

-- 2. Insert Default Admin
-- Password is 'Admin@123' (bcrypt hash: $2a$10$wKz0bB4n36JkE4l5UfF1fe07pD3y0Y1.n3W8sB2wHwZ4UqD3g7f9q)
INSERT INTO admins (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@lab.edu', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2', 'Chief Lab Administrator', 'ADMIN');

-- 3. Insert Sample Students
-- Passwords are 'student123'
INSERT INTO students (student_id, name, email, department, year, password_hash) VALUES
('STU101', 'Rahul Sharma', 'rahul.s@college.edu', 'Computer Science & Engineering', '2nd Year', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2'),
('STU102', 'Priya Patel', 'priya.p@college.edu', 'Computer Science & Engineering', '2nd Year', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2'),
('STU103', 'Ananya Verma', 'ananya.v@college.edu', 'Information Technology', '2nd Year', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2'),
('STU104', 'Karthik Rao', 'karthik.r@college.edu', 'Computer Science & Engineering', '3rd Year', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2'),
('STU105', 'Sneha Reddy', 'sneha.r@college.edu', 'AI & Machine Learning', '2nd Year', '$2a$10$e8eD06Hq5q4M1wA6B1vX5eA5xJ8y.9xJ4t2K6L8M0N2P4Q6R8S0T2');

-- 4. Initial System Activity Log
INSERT INTO activity_logs (action_type, actor, description, semaphore_before, semaphore_after) VALUES
('SYSTEM_INIT', 'SYSTEM', 'Operating System Laboratory Workstation Allocation System initialized with 10 workstations. Semaphore S = 10.', 10, 10);
