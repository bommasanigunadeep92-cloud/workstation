-- Computer Laboratory Workstation Allocation System
-- Database Schema: MySQL 8.0+

CREATE DATABASE IF NOT EXISTS workstation_allocation_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE workstation_allocation_db;

-- 1. Workstations Table
-- Represents physical computer workstations in the laboratory (PC-01 to PC-10)
CREATE TABLE IF NOT EXISTS workstations (
  id VARCHAR(10) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  status ENUM('AVAILABLE', 'OCCUPIED', 'RESERVED') NOT NULL DEFAULT 'AVAILABLE',
  current_student_id VARCHAR(50) NULL,
  ip_address VARCHAR(45) DEFAULT '192.168.1.100',
  specs VARCHAR(255) DEFAULT 'Intel Core i7, 16GB RAM, Ubuntu 22.04 LTS',
  last_allocated_at DATETIME NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. Students Table
CREATE TABLE IF NOT EXISTS students (
  student_id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  department VARCHAR(50) DEFAULT 'Computer Science & Engineering',
  year VARCHAR(10) DEFAULT '2nd Year',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Admins Table
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) DEFAULT 'Laboratory Administrator',
  role VARCHAR(20) DEFAULT 'ADMIN',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Allocations Table
-- History and active records of computer assignments
CREATE TABLE IF NOT EXISTS allocations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  workstation_id VARCHAR(10) NOT NULL,
  status ENUM('ACTIVE', 'COMPLETED', 'REVOKED') NOT NULL DEFAULT 'ACTIVE',
  allocated_at DATETIME NOT NULL,
  released_at DATETIME NULL,
  duration_seconds INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
  FOREIGN KEY (workstation_id) REFERENCES workstations(id) ON DELETE CASCADE,
  INDEX idx_student_status (student_id, status),
  INDEX idx_workstation_status (workstation_id, status)
);

-- 5. Waiting Queue Table
-- First-In First-Out (FIFO) queue for students when Semaphore S = 0
CREATE TABLE IF NOT EXISTS waiting_queue (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id VARCHAR(50) NOT NULL,
  position INT NOT NULL,
  status ENUM('WAITING', 'ALLOCATED', 'CANCELLED') NOT NULL DEFAULT 'WAITING',
  request_time DATETIME NOT NULL,
  resolved_time DATETIME NULL,
  allocated_workstation_id VARCHAR(10) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
  INDEX idx_status_position (status, position)
);

-- 6. Activity Logs Table
-- System audit log tracking OS events, semaphore transitions, and allocations
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  action_type VARCHAR(50) NOT NULL,
  actor VARCHAR(50) DEFAULT 'SYSTEM',
  description TEXT NOT NULL,
  semaphore_before INT NOT NULL,
  semaphore_after INT NOT NULL,
  workstation_id VARCHAR(10) NULL,
  student_id VARCHAR(50) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
