# Computer Laboratory Workstation Allocation System Using Counting Semaphore

A full-stack academic Operating Systems web application to manage finite laboratory workstations using Dijkstra's **Counting Semaphore**, **Process Synchronization**, **Critical Section Protection**, **FIFO Waiting Queue**, and **Direct Resource Handoff**.

---

## 📚 Table of Contents
1. [Core Operating Systems Concepts](#-core-operating-systems-concepts)
2. [Project Architecture & Folder Structure](#-project-architecture--folder-structure)
3. [Technology Stack](#-technology-stack)
4. [Installation & Setup](#-installation--setup)
5. [How to Run the Application](#-how-to-run-the-application)
6. [Live Faculty Demonstration Guide (5 PCs & 7 Students)](#-live-faculty-demonstration-guide-5-pcs--7-students)
7. [Comprehensive Viva Questions & Answers](#-comprehensive-viva-questions--answers)
8. [Automated Testing Suite](#-automated-testing-suite)

---

## 🧠 Core Operating Systems Concepts

### 1. Counting Semaphore ($S$)
A synchronization variable initialized to the number of available identical resource units ($N=10$ workstations).
- When a student process requests a workstation:
  - If $S > 0$: $S \gets S - 1$, and access to a workstation is granted.
  - If $S = 0$: No free workstation is available. The process is **blocked** and placed in the **FIFO Waiting Queue**.
- **Crucial Rule**: $S$ can never become negative.

### 2. Wait Operation: $P(S)$ / `wait(S)`
```c
void wait(Semaphore S, Process P) {
    mutex_lock();
    if (S.value > 0) {
        S.value--;
        allocate_workstation(P);
    } else {
        S.waiting_queue.enqueue(P);
        block(P);
    }
    mutex_unlock();
}
```

### 3. Signal Operation: $V(S)$ / `signal(S)` with Direct Resource Handoff
```c
void signal(Semaphore S, Workstation W) {
    mutex_lock();
    if (!S.waiting_queue.isEmpty()) {
        Process next_process = S.waiting_queue.dequeue();
        direct_handoff(W, next_process); // S.value DOES NOT increment!
    } else {
        W.status = AVAILABLE;
        S.value++;
    }
    mutex_unlock();
}
```
> [!IMPORTANT]
> **Direct Resource Handoff Principle**: If students are waiting in the queue, releasing a workstation does NOT increment $S$! The workstation is handed off directly from the leaving student to the head of the FIFO waiting queue. $S$ remains 0 because all workstations are still continuously in use.

### 4. Critical Section & Mutual Exclusion (Mutex)
The critical section is the code segment where shared variables (such as $S$, workstation occupancy maps, and the waiting queue) are inspected and mutated. A mutual exclusion lock (`Mutex`) guarantees that **only one request** manipulates these variables at any given millisecond, completely preventing race conditions.

### 5. Race Condition
A concurrency bug where multiple concurrent requests attempt to read and modify shared memory simultaneously, resulting in double-allocation (assigning the same workstation to two students). In this project, dual-layer protection (in-memory Mutex queue + MySQL transactions with `FOR UPDATE`) eliminates race conditions.

---

## 📁 Project Architecture & Folder Structure

```
workstation-allocation-system/
├── backend/
│   ├── config/
│   │   └── db.js                 # MySQL2 connection pool with resilient fallback
│   ├── controllers/
│   │   ├── authController.js        # Student/Admin registration, login, session
│   │   ├── workstationController.js # Workstation listing and laboratory metrics
│   │   ├── allocationController.js  # wait(S), signal(S), queue, admin reset
│   │   └── analyticsController.js   # Usage stats, history, audit logs
│   ├── middleware/
│   │   └── auth.js                  # Student & Admin session authentication guards
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── workstationRoutes.js
│   │   ├── allocationRoutes.js
│   │   └── analyticsRoutes.js
│   ├── services/
│   │   └── allocationService.js     # Transactional OS logic, handoff, broadcasting
│   ├── socket/
│   │   └── socketHandler.js         # Socket.IO bi-directional real-time event bus
│   ├── test/
│   │   ├── semaphore.test.js        # Tests 1-6 (Initialization, saturation, queue, handoff)
│   │   └── concurrency.test.js      # Tests 7-10 (Simultaneous requests, mutex locking)
│   ├── utils/
│   │   └── semaphore.js             # CountingSemaphore & Mutex kernel classes
│   └── server.js                    # Express app & Socket.IO server startup
├── database/
│   ├── schema.sql                   # MySQL relational tables & indexes
│   ├── seed.sql                     # Seed data (10 PCs, default admin, sample students)
│   └── local_storage.json           # Persistent fallback storage
├── frontend/
│   ├── css/
│   │   └── main.css                 # Dark navy university lab theme
│   ├── js/
│   │   ├── api.js                   # Unified fetch API client & toast notifications
│   │   └── socket.js                # Socket.IO client event synchronization
│   ├── index.html                   # Landing page with interactive flowchart & metrics
│   ├── login.html                   # Student & Admin login with quick demo buttons
│   ├── register.html                # Student registration form
│   ├── student-dashboard.html       # Student workspace with live duration timer & queue
│   ├── admin-dashboard.html         # Admin layout with PC-01 to PC-10 grid & audit trail
│   ├── simulation.html              # Dedicated OS step-by-step & auto simulation lab
│   └── analytics.html               # Chart.js analytics charts & CSV export
├── .env                             # Environment configuration
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

---

## 🛠️ Technology Stack
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla ES6+), Bootstrap 5, Bootstrap Icons, Chart.js
- **Backend**: Node.js, Express.js, Socket.IO, express-session, bcryptjs
- **Database**: MySQL 8.0 / MySQL2 with connection pool + self-contained fallback engine
- **Testing**: Node assert test runner

---

## 🚀 Installation & Setup

1. **Navigate to the project directory**:
   ```powershell
   cd c:\Users\abhin\Downloads\os-2
   ```

2. **Install dependencies** (already installed):
   ```powershell
   npm install
   ```

3. **Database Configuration** (Optional):
   - MySQL service `MySQL80` runs on port 3306.
   - You can enter your MySQL root password inside `.env`:
     ```env
     PORT=5000
     DB_HOST=localhost
     DB_PORT=3306
     DB_USER=root
     DB_PASSWORD=your_mysql_password
     DB_NAME=workstation_allocation_db
     ```
   - **Out-of-the-Box Resilience**: If MySQL credentials are not configured, the system automatically activates an embedded relational engine with zero crashes, preserving persistence in `database/local_storage.json`.

---

## 💻 How to Run the Application

### 1. Start the Server:
```powershell
npm start
```
The server will start on port **5000**.

### 2. Access the Application:
- **Landing Page**: [http://localhost:5000](http://localhost:5000)
- **Student Dashboard**: [http://localhost:5000/student-dashboard.html](http://localhost:5000/student-dashboard.html)
- **Admin Dashboard**: [http://localhost:5000/admin-dashboard.html](http://localhost:5000/admin-dashboard.html)
- **OS Simulation Lab**: [http://localhost:5000/simulation.html](http://localhost:5000/simulation.html)
- **Lab Analytics**: [http://localhost:5000/analytics.html](http://localhost:5000/analytics.html)

### 3. Demo Credentials:
- **Admin Account**: `admin` / `Admin@123` (use the "Autofill Admin" button)
- **Sample Student**: `STU101` / `student123` (use the "Autofill Student" button)

---

## 🧪 Run Automated Tests
Execute the OS test suite verifying all 10 academic requirements:
```powershell
npm test
```
All tests will output green checkmarks demonstrating $P(S)$, $V(S)$, Direct Handoff, and Concurrency safety!

---

## 🎓 Live Faculty Demonstration Guide (5 PCs & 7 Students)

Here is the exact script to demonstrate your project to your external examiner or college faculty:

### Step 1: Open the OS Simulation Laboratory
1. Open [http://localhost:5000/simulation.html](http://localhost:5000/simulation.html).
2. Point out:
   - "Respected Examiner, here is the Counting Semaphore register initialized to $S = 10$."
   - "Here are the 10 physical workstation slots."
   - "Here is the FIFO Waiting Queue."

### Step 2: Show the Request Operation (`wait(S)`)
1. Click **"Request Workstation"** repeatedly:
   - Student 1 requests $\to S = 9$, `PC-01` turns red (Occupied).
   - Student 2 requests $\to S = 8$, `PC-02` turns red.
   - Continue until 10 students allocate $\to S = 0$, all 10 PCs turn red.
2. Explain to faculty:
   - *"Each request enters the Critical Section, executes $P(S)$ / `wait(S)`, and decrements $S$ atomically."*

### Step 3: Show FIFO Waiting Queue when $S = 0$
1. Click **"Request Workstation"** again:
   - Student 11 requests $\to$ Cannot allocate because $S=0$.
   - Student 11 enters the **FIFO Waiting Queue** at Position #1.
   - Student 12 requests $\to$ Joins the queue at Position #2.
   - Point out that **$S$ remains 0** and does NOT become negative!

### Step 4: Show the Core OS Concept: Direct Resource Handoff
1. Click **"Release Workstation"** (simulating Student 3 logging out):
   - `PC-03` is released.
   - But notice: **$S$ DOES NOT INCREMENT! $S$ remains 0!**
   - Student 11 immediately acquires `PC-03` via **Direct Resource Handoff**.
   - Student 12 automatically advances to Position #1 in the queue.
2. Explain to faculty:
   - *"Sir, this demonstrates true OS Direct Handoff. Because a process was waiting in the FIFO queue, releasing the resource did not return it to the idle pool ($S$ stays 0); instead, the token was handed directly to the first blocked process."*

### Step 5: Show Signal Operation (`signal(S)`)
1. Release workstations until the queue becomes empty.
2. When the queue is empty, clicking release executes standard $V(S)$ / `signal(S)` $\to S$ increments from 0 to 1, then 2, then 3.

### Step 6: Show Real-Time Dashboards
1. Open **Student Dashboard** in one tab and **Admin Dashboard** in another tab side-by-side.
2. Click "Request Workstation" on the Student tab $\to$ notice the Admin tab updates immediately via **Socket.IO** without manual page refresh.

---

## ❓ Comprehensive Viva Questions & Answers

#### Q1: What is a Counting Semaphore?
**Answer**: A Counting Semaphore is an integer synchronization variable initialized to the number of available identical resource units ($N$). Its value can range from 0 to $N$. When a process requests a resource, it executes `wait()` which decrements the value. When a process finishes with a resource, it executes `signal()` which increments the value.

#### Q2: What is the difference between a Binary Semaphore and a Counting Semaphore?
**Answer**:
- A **Binary Semaphore** can only take values 0 or 1, serving as a mutual exclusion lock (Mutex) to protect a critical section.
- A **Counting Semaphore** takes non-negative integer values ($0, 1, 2, \dots, N$), representing multiple identical instances of a resource (in our project, 10 computer workstations).

#### Q3: What is the Critical Section Problem and how did you solve it?
**Answer**: The Critical Section is a segment of code where shared resources are accessed. If two processes execute this section concurrently, inconsistent states and race conditions occur. In our project, we solved it using an asynchronous mutual exclusion `Mutex` lock in the Node.js backend combined with database row locking (`SELECT ... FOR UPDATE`), guaranteeing atomic check-and-decrement.

#### Q4: Why doesn't the Semaphore increment when a workstation is released if students are waiting?
**Answer**: This is called **Direct Resource Handoff**. When a student finishes, if another student is already blocked in the FIFO queue, the workstation is transferred directly to that student without returning to the idle pool. Because all resources remain fully occupied, the available count $S$ remains 0.

#### Q5: Can the Counting Semaphore value become negative?
**Answer**: In classical theoretical semaphore definitions (like Tanenbaum's), a negative value represents the number of waiting processes (e.g. $-2$ means 2 waiting). In Dijkstra's non-negative semaphore convention and our laboratory system, $S$ is strictly bounded to $S \ge 0$, representing available resources, while blocked processes are maintained in a dedicated FIFO waiting queue structure.

#### Q6: How do you prevent race conditions during simultaneous requests?
**Answer**: By synchronizing requests inside the backend service using a FIFO mutex queue. Even if 20 HTTP requests arrive at the exact same millisecond, each request enters the critical section sequentially, evaluates $S$, and either acquires an available workstation or is queued with a distinct, consecutive queue position.
